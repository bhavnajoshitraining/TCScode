package com.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car car = new Car("bhavi", 1000);
		Car newca = null;
		
		try {
			FileOutputStream fa = new FileOutputStream("a.txt");
			ObjectOutputStream o = new ObjectOutputStream(fa);
			o.writeObject(car);
			o.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			FileInputStream fi = new FileInputStream("a.txt");
			ObjectInputStream si = new ObjectInputStream(fi);		
			newca = (Car) si.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Original car "+car);
		System.out.println("new car is "+newca);
	}

}
