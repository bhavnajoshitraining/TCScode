package com.demo;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Car implements Externalizable {

	static int age;
	String name;
	int year;
	
	public Car() {
		System.out.println("Default called!!");
	}

	@Override
	public String toString() {
		return "Car [name=" + name + ", year=" + year + "]";
	}

	public Car(String name, int year) {
		super();
		this.name = name;
		this.year = year;
	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(name);
		out.writeInt(age);
		out.writeInt(year);

	}

	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		name = (String)in.readObject();
		year = in.readInt();
		age = in.readInt();
	}

}
