package com.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo object = new Demo(1, "Bhavna");
		String fname = "a.ser";
		
		try {
			FileOutputStream file = new FileOutputStream(fname);
			ObjectOutputStream out = new ObjectOutputStream(file);
			
			out.writeObject(object);
			out.close();
			file.close();
			System.out.println("Object has been serialized!!!");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		Demo object1 = null;
		
		try {
			FileInputStream file = new FileInputStream(fname);
			ObjectInputStream in = new ObjectInputStream(file);
			
			object1 = (Demo) in.readObject();
			
			in.close();
			file.close();
			
			System.out.println("Object is deSerialized!!");
			System.out.println("a = "+object.a);
			System.out.println("name = "+object.name);
			
		} catch (IOException e) {
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
