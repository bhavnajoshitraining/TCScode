package com.demo;

import java.io.Serializable;
import java.util.concurrent.Flow.Publisher;

public class Demo implements Serializable{

	public int a;
	public String name;
	
	
	public Demo(int a, String name) {
		super();
		this.a = a;
		this.name = name;
	}
	

}
