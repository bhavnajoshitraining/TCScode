package com.demo;

import org.hibernate.Session;

import com.demo.model.Student;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println( "Hello World!" );
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        
        Student s1 = new Student();
        s1.setFirstName("Neha");
        s1.setLastName("jos");
        s1.setEmail("123@gmail.com");
        session.save(s1);
        
        Student s2 = new Student();
        s2.setFirstName("me");
        s2.setLastName("mo");
        s2.setEmail("mo3@gmail.com");
        session.save(s2);
        
        session.getTransaction().commit();
        
        HibernateUtil.shutdown();
        
	}
}