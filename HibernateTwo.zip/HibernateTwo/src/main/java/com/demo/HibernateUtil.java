package com.demo;

import java.io.File;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil {
	private static final SessionFactory sfactory = buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		try {
			return new AnnotationConfiguration().configure(new File("hibernate.cfg.xml")).buildSessionFactory();
		} catch (Throwable e) {
			throw new ExceptionInInitializerError(e);
		}
	}
	
	public static SessionFactory getSessionFactory() {
		return sfactory;
	}
	
	public static void shutdown() {
		try {
			getSessionFactory().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
