package com.demo.hier;

public class Animal {

	void breath() {
		System.out.println("Breathing ..... in open environment!!!");
	}
}
