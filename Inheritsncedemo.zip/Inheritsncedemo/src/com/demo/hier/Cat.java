package com.demo.hier;

public class Cat extends Animal {

	void eat() {
		System.out.println("I eat milk and bread!!!");
	}
}
