package com.demo.hier;

public class Dog extends Animal {

	public void run() {
		System.out.println("I think i run faster then cat!!");
	}
}
