package com.demo.hier;

public class Lion extends Animal {
	public void display() {
		System.out.println("I am King-Kong");
	}
}
