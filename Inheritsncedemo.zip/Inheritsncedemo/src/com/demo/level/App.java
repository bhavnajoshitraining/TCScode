package com.demo.level;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Science science = new Science("Bhavna", 1, "H2o", "RTU", 10);
		//create notificationxam() in director and motivationSession() in education.
		System.out.println(science);
		science.notificationxam();
		science.motivationSession();
		//create object of science and use functions of Education and Director class.
	}

}
