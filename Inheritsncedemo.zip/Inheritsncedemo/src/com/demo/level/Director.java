package com.demo.level;

public class Director {

	String name;
	int id;
	
	public void notificationxam() {
		System.out.println("Your Exam will start from Monday!!");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Director(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Director [name=" + name + ", id=" + id + "]";
	}
}
