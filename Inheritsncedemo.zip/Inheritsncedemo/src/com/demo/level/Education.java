package com.demo.level;

public class Education extends Director {

	String nameOfclg;
	int num_of_candidates;
	
	public void motivationSession() {
		System.out.println("Tough times never last, tough people do!!!!");
	}
	
	public Education(String name, int id) {
		super(name, id);
		// TODO Auto-generated constructor stub
	}

	public Education(String name, int id, String nameOfclg, int num_of_candidates) {
		super(name, id);
		this.nameOfclg = nameOfclg;
		this.num_of_candidates = num_of_candidates;
	}

	public String getNameOfclg() {
		return nameOfclg;
	}

	public void setNameOfclg(String nameOfclg) {
		this.nameOfclg = nameOfclg;
	}

	public int getNum_of_candidates() {
		return num_of_candidates;
	}

	public void setNum_of_candidates(int num_of_candidates) {
		this.num_of_candidates = num_of_candidates;
	}
	
}
