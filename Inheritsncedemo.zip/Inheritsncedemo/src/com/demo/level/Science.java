package com.demo.level;

public class Science extends Education {
 
	String exp;
	
	public Science(String name, int id, String nameOfclg, int num_of_candidates) {
		super(name, id, nameOfclg, num_of_candidates);
		// TODO Auto-generated constructor stub
	}

	public Science(String name, int id, String exp,String nameOfclg, int num_of_candidates) {
		super(name, id, nameOfclg, num_of_candidates);
		this.exp = exp;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

	@Override
	public String toString() {
		return "Science [exp=" + exp + ", nameOfclg=" + nameOfclg + ", num_of_candidates=" + num_of_candidates
				+ ", name=" + name + ", id=" + id + "]";
	}
}
