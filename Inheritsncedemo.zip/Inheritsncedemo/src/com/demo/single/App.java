package com.demo.single;

public class App {

	public static void main(String[] args) {
		Bangalore bangalore = new Bangalore();
		bangalore.pincode = 56001;
		bangalore.name = "bangaluru";
		bangalore.special_food = "Mysore pak";
		bangalore.famous_cloth = "Silk";
		bangalore.population = 1111111;
		
		System.out.println( bangalore.toString()+" pincode:-"+bangalore.pincode+" ");
		
		System.out.println(bangalore.celebrate("New Year"));

	}

}
