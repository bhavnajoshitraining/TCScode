package com.demo.single;

public class Bangalore extends City {
	String special_food;
	String famous_cloth;
	int population;
	
	public Bangalore() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bangalore(int pincode, String name) {
		super(pincode, name);
		// TODO Auto-generated constructor stub
	}
	public String getSpecial_food() {
		return special_food;
	}
	public void setSpecial_food(String special_food) {
		this.special_food = special_food;
	}
	public String getFamous_cloth() {
		return famous_cloth;
	}
	public void setFamous_cloth(String famous_cloth) {
		this.famous_cloth = famous_cloth;
	}
	public int getPopulation() {
		return population;
	}
	public void setPopulation(int population) {
		this.population = population;
	}
	@Override
	public String toString() {
		return "Bangalore [special_food=" + special_food + ", famous_cloth=" + famous_cloth + ", population="
				+ population + "]";
	}
	public String celebrate(String fun) {
		System.out.println(super.celebrate("myfunction"));
		return fun+", i am celebrating this from bangalore";
	}
	
}
