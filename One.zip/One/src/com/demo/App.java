package com.demo;

import com.demo.fun.Marksheet;
import com.demo.operators.Calculator;

public class App {

	public static void main(String[] args) {
		Marksheet m1= new Marksheet(6,7,8,9,"bhanu");
		Marksheet m2= new Marksheet(5,2,6,7,"aishwarya");
		
		System.out.println(m1.comparemarks(m1, m2)+ " is topper");
}
}