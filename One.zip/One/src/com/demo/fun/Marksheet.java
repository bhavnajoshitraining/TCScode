package com.demo.fun;

public class Marksheet {

	int maths;
	int hindi;
	int english;
	int science;
	String student_name;
	
	public Marksheet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Marksheet(int maths, int hindi, int english, int science, String student_name) {
		super();
		this.maths = maths;
		this.hindi = hindi;
		this.english = english;
		this.science = science;
		this.student_name = student_name;
	}
	public int getMaths() {
		return maths;
	}
	public void setMaths(int maths) {
		this.maths = maths;
	}
	public int getHindi() {
		return hindi;
	}
	public void setHindi(int hindi) {
		this.hindi = hindi;
	}
	public int getEnglish() {
		return english;
	}
	public void setEnglish(int english) {
		this.english = english;
	}
	public int getScience() {
		return science;
	}
	public void setScience(int science) {
		this.science = science;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	
	public int calculateResult(Marksheet m) {
		int result = m.english+m.hindi+m.maths+m.science;
		return result;
	}
	
	public String comparemarks(Marksheet m1,Marksheet m2) {
		int r1 = calculateResult(m1);
		int r2 = calculateResult(m2);
		if(r1>r2) {
			return m1.student_name;
		}else {
			return m2.student_name;
		}
	}
}
