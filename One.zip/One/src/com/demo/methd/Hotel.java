package com.demo.methd;

public class Hotel {

	int roomNo;
	int tableNo;
	int orderNo;
	String custName;
	
	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Hotel(int roomNo, int tableNo, int orderNo, String custName) {
		super();
		this.roomNo = roomNo;
		this.tableNo = tableNo;
		this.orderNo = orderNo;
		this.custName = custName;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public int getTableNo() {
		return tableNo;
	}
	public void setTableNo(int tableNo) {
		this.tableNo = tableNo;
	}
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	@Override
	public String toString() {
		return "Hotel [roomNo=" + roomNo + ", tableNo=" + tableNo + ", orderNo=" + orderNo + ", custName=" + custName
				+ "]";
	}
	
	public void display() {
		System.out.println("Hello World!!!!");
	}
	
	public float calcuatebill() {
		return 1.2f;
	}
	
	public int calculateSum(int a, int b) {
		return a+b;
	}
}
