package com.demo.operators;

public class Calculator {

	public void sayHello() {
		System.out.println("Hello World");
	}
	
	public int sum(int a, int b) {
		return a+b;
	}
	
	public int diff(int a, int b) {
		return a-b;
	}
	
	public int mult(int a, int b) {
		return a*b;
	}
	
	public int divs(int a, int b) {
		return a/b;
	}
	
	public int moduls(int a, int b) {
		return a%b;
	}
	
}
