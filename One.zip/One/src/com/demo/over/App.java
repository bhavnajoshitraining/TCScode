package com.demo.over;

public class App {

	public static void main(String[] args) {
		Calc calc = new Calc();
		
		int res = calc.sum(2, 3);
		int res1 = calc.sum(1, 2, 3);
		double res2 = calc.sum(1.1d, 1.4d, 1);
		
		System.out.println("2 para: "+res);
		System.out.println("3 para "+res1);
		System.out.println("double "+res2);

	}

}
