package com.demo.over;

public class Calc {

	public int sum(int a, int b) {
		return a+b;
	}
	
	public int sum(int a, int b,int c) {
		return a+b+c;
	}
	
	public double sum(double a, double b,int c) {
		return a+b+c;
	}
	
	public int diff(int a, int b) {
		return a-b;
	}
	
	public int diff(int a, int b,int c) {
		return a-b;
	}
	
	public double diff(double a, double b) {
		return a-b;
	}
}
