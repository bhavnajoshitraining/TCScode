package com.demo.sports;

public class Sportsman {

	int height;
	int weight;
	String name;
	int s1,s2,s3;
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getS1() {
		return s1;
	}
	public void setS1(int s1) {
		this.s1 = s1;
	}
	public int getS2() {
		return s2;
	}
	public void setS2(int s2) {
		this.s2 = s2;
	}
	public int getS3() {
		return s3;
	}
	public void setS3(int s3) {
		this.s3 = s3;
	}
	public Sportsman(int height, int weight, String name, int s1, int s2, int s3) {
		super();
		this.height = height;
		this.weight = weight;
		this.name = name;
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
	}
	public Sportsman() {
	}
	@Override
	public String toString() {
		return "Sportsman [height=" + height + ", weight=" + weight + ", name=" + name + ", s1=" + s1 + ", s2=" + s2
				+ ", s3=" + s3 + "]";
	}
	
	public String compareHeight(Sportsman s1, Sportsman s2) {
		if(s1.height>s2.height) {
			return s1.name;
		}else {
			return s2.name;
		}
	}
}
