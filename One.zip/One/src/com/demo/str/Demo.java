package com.demo.str;

public class Demo {

	public static void main(String[] args) {
		String s1 = "JavaTraining";
		String s2 = "Javatraining";
		String s3 = "      Comple teRef";
		
		boolean a = s1.equals(s2);
		System.out.println("comparision result s1,s2 "+a);
		
		System.out.println("char at 4 in s3 that is CompleteRef"+s3.charAt(4));
		System.out.println("concat s1 with s2 and s3 and another string"+s1.concat(s2).concat(s3).concat("bye-bye"));
		System.out.println(s1.toUpperCase());
		System.out.println(s1.toLowerCase());
		System.out.println(s1.indexOf('T'));
		System.out.println(s2.substring(0,6));
		System.out.println(s2.substring(6));
		System.out.println(s1.equals(s2));
		System.out.println(s1.equalsIgnoreCase(s2));
		System.out.println(s3);
		System.out.println(s3.trim());
		//create a string
//		String s = "Bhavna";
//		String str = new String("Joshi");
//		System.out.println(s);
//		System.out.println(str);
//		
//		int a = s.length();
//		System.out.println("Length of s is "+a);
//		
//		String bString = s+ " "+str;
//		System.out.println(bString);
//		System.out.println(bString.toLowerCase());
//		System.out.println(bString.toUpperCase());
//		System.out.println(bString.indexOf("o"));
		
//		String aString = "1";
//		String bString = "3";
//		int a =10;
////		String sumString = aString+bString;
//		String sumString = aString+a;
//		System.out.println(sumString);

		
	}

}

