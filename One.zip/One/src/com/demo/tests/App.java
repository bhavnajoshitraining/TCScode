package com.demo.tests;

public class App {

	public static void main(String[] args) {
		Demo d = new Demo();

		d.display();
		d.displayFullname("bhavna", "joshi");
		d.displayMyInfo("bhanu", "Mentor", "TCS", "Bangalore");
		d.displayName("bhavna");
		int b = d.tellyourage("sonu");
		System.out.println(b);
	}

}
