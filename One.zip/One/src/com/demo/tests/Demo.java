package com.demo.tests;

public class Demo {

	public void display() {
		System.out.println("Hello Team!!");
	}
	
	public void displayName(String name) {
		System.out.println(name+ " is a java Developer");
	}
	
	public void displayFullname(String fname,String lname) {
		System.out.println(fname+" "+lname);
	}
	
	public void displayMyInfo(String name, String design, String company,String address) {
		System.out.println(name+" "+design+" "+company+" "+address);
	}
	
	public int tellyourage(String name) {
		int a = 10;
		System.out.println("age of "+name+" is"+a);
		return a;
	}
}
