package com.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class App {

	public static void main(String[] args) throws IOException {
		System.out.println("Welcome to the Student Management System!!!");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		while(true) {
			System.out.println("Press 1 to Add student");
			System.out.println("Press 2 to Delete student");
			System.out.println("Press 3 to Display student");
			System.out.println("Press 4 to Update Student");
			System.out.println("Press 5 to Exit Application");
			
			int choice = Integer.parseInt(br.readLine());
			
			System.out.println("You Entered "+choice);
			
			switch (choice){
			case 1:
				System.out.println("Enter first name of the student :");
				String fname = br.readLine();
				System.out.println("Enter last name of the student :");
				String lname = br.readLine();
				System.out.println("Enter Stand of the student :");
				int stand = Integer.parseInt(br.readLine());
				
				Student student = new Student(fname,lname,stand);
				System.out.println(student);
				
				boolean ans = StudentDao.insertStudentToDB(student);
				
				if(ans) {
					System.out.println("Value inserted!!");
				}else {
					System.out.println("Sorry we failed to insert!!");
				}
				break;
			case 2:
				System.out.println("Id to delete:- ");
				int id = Integer.parseInt(br.readLine());
				boolean ans1 = StudentDao.deleteStudent(id);

				if(ans1) {
					System.out.println("Value deleted!!");
				}else {
					System.out.println("Sorry we failed to delete!!");
				}
				break;
			case 3:
				boolean f = StudentDao.showAllStudents();
				break;
			case 4:
				break;
			case 5:
				System.out.println("Thanks for using our app!!");
				System.exit(0);
				break;
			default:
				break;
			}
		}

	}

}
