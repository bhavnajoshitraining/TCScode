package com.model;

import java.lang.invoke.StringConcatFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.cj.protocol.Resultset;

public class StudentDao {
	public static boolean insertStudentToDB(Student student) {
		boolean f = false;
		try {
			Connection connection = CP.createConnection();
			String query= "insert into student(fname,lname,stand) values(?,?,?)";
			
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, student.getFname());
			preparedStatement.setString(2, student.getLname());
			preparedStatement.setInt(3, student.getStand());
			
			preparedStatement.executeUpdate();
			f=true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return f; 
	}
	
	public static boolean deleteStudent(int StudentId) {
		boolean f =false;
		try {
			Connection connection = CP.createConnection();
			String query= "delete from student where id=?";
			
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, StudentId);
			preparedStatement.executeUpdate();
			f=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	public static boolean showAllStudents() {
		boolean f = false;
		try {
			Connection connection = CP.createConnection();
			String query= "select * from student";
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			
			while(resultset.next()) {
				int id = resultset.getInt(1);
				String fname = resultset.getString(2);
				String lname = resultset.getString(3);
				int stand = resultset.getInt(4);
				
				System.out.println(id);
				System.out.print(fname);
				System.out.print(lname);
				System.out.print(stand);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return f;
	}
}
