package com.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class App implements Serializable{

	int a=1;
	int b=2;
	transient int c=3;
	transient static int d=3;
	transient final int e=3;
	
	public static void main(String[] args) throws Exception {
		App app = new App();
		FileOutputStream f = new FileOutputStream("a.txt");
		ObjectOutputStream o= new ObjectOutputStream(f);
		o.writeObject(app);
		
		FileInputStream a = new FileInputStream("a.txt");
		ObjectInputStream i = new ObjectInputStream(a);
		
		App output = (App) i.readObject();
		
		System.out.println("a= "+output.a);
		System.out.println("b= "+output.b);
		System.out.println("c= "+output.c);
		System.out.println("d= "+output.d);
		System.out.println("e= "+output.e);

	}

}
